package InterfaceAndAbstraction.Telephony;

public interface Browsable {
    String browse();
}
