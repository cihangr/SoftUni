package InterfaceAndAbstraction.Telephony;

public interface Callable {
    String call();
}
