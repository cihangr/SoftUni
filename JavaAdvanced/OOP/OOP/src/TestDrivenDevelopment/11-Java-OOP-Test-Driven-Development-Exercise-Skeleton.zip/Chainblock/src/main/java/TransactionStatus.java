public enum TransactionStatus {
    FAILED,
    SUCCESSFUL,
    ABORTED,
    UNAUTHORIZED
}
