package dolphinarium.entities.foods;

public interface Food {
//TODO Implement all methods


    int getCalories();

}
