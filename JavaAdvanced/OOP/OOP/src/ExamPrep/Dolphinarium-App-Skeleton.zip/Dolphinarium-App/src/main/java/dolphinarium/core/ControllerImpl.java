package dolphinarium.core;
//TODO Implement all methods
public class ControllerImpl implements Controller{
    @Override
    public String addPool(String poolType, String poolName) {
        return null;
    }

    @Override
    public String buyFood(String foodType) {
        return null;
    }

    @Override
    public String addFoodToPool(String poolName, String foodType) {
        return null;
    }

    @Override
    public String addDolphin(String poolName, String dolphinType, String dolphinName, int energy) {
        return null;
    }

    @Override
    public String feedDolphins(String poolName, String food) {
        return null;
    }

    @Override
    public String playWithDolphins(String poolName) {
        return null;
    }

    @Override
    public String getStatistics() {
        return null;
    }
}
