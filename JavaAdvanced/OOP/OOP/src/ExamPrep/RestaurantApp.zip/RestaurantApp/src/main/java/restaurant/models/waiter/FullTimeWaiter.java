package restaurant.models.waiter;

//TODO
public class FullTimeWaiter {

}
