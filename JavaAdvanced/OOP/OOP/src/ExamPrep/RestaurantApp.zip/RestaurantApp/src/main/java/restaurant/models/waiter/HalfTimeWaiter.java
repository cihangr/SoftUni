package restaurant.models.waiter;

//TODO
public class HalfTimeWaiter  {

}
