package restaurant.models.waiter;

//TODO
public abstract class BaseWaiter {

}
