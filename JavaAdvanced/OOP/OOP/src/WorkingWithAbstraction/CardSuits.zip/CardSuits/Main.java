package WorkingWithAbstraction.CardSuits;
/*
@CIHAN GUR

Create an enumeration type that has as its constants the four suits of a deck of playing cards
(CLUBS, DIAMONDS, HEARTS, SPADES). Iterate over the values of the enumeration type and print all ordinal values and names.


>>>>>INPUT
Card Suits
>>>>>OUTPUT
Card Suits:
Ordinal value: 0; Name value: CLUBS
Ordinal value: 1; Name value: DIAMONDS
Ordinal value: 2; Name value: HEARTS
Ordinal value: 3; Name value: SPADES

*/
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        CardSuits[] cards = CardSuits.values();
        System.out.print("Card Suits:\n");
        for (CardSuits card : cards) {
            int ordinal = card.ordinal();
            System.out.printf("Ordinal value: %d; Name value: %s\n",ordinal, card.name());
        }


    }
}
