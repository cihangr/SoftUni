package WorkingWithAbstraction.TrafficLights;

public enum Lights {
    RED,
    GREEN,
    YELLOW,
}
