package WorkingWithAbstraction.CardSuits;

public enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;



}
